package io.cocoa.health;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    Button button1;
    ImageView flower;
    SeekBar sk;
    int numClick = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1); // initialize button
        button1.setOnClickListener(this);

        flower = findViewById(R.id.imageView2); // initial flower image

        sk = findViewById(R.id.seekBar3); // initialize seek bar
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // I want the bar to actually do something
            int prog = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sk.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onClick(View v) {
        if(v == button1) {
//            if(sk.getVisibility() == View.VISIBLE) {
//                sk.setVisibility(View.INVISIBLE);
//            }
//           else
//                sk.setVisibility(View.VISIBLE);
            if(numClick == 0) {
                flower.setImageResource(R.drawable.flower1);
                numClick++;
            }
            else { // numClick > 0
                flower.setImageResource(R.drawable.flower2);
                numClick = 0;
            }
        }
    }
}