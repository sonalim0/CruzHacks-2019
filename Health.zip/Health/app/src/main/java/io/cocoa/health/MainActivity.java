package io.cocoa.health;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    Button button1;
    ImageView seed;
    SeekBar sk;
    int numClick = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1); // initialize button
        button1.setOnClickListener(this);

        seed = findViewById(R.id.imageView2); // initial seed image

        sk = findViewById(R.id.seekBar3); // initialize seek bar
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // I want the bar to actually do something
            int prog = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sk.setVisibility(View.INVISIBLE); // seek bar does nothing for now
    }

    @Override
    public void onClick(View v) {
        if(v == button1) {
            if(numClick < 4) {
                if(numClick == 0)
                    seed.setImageResource(R.drawable.seed1);
                else if(numClick == 1)
                    seed.setImageResource(R.drawable.seed2);
                else if(numClick == 2)
                    seed.setImageResource(R.drawable.seed3);
                else
                    seed.setImageResource(R.drawable.seed4);
                numClick++;
            }
            else { // numClick == 4
                seed.setImageResource(R.drawable.seed5);
                numClick = 0; // reset numClick
            }
        }
    }
}